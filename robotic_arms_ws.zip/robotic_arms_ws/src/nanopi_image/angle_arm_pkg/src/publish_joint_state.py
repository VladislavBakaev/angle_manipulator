#!/usr/bin/env python
import rospy
from sensor_msgs.msg import JointState
import math
from inverse_problem_srv.srv import publish_cmd,publish_cmdResponse

jointPub = rospy.Publisher('/cmd_joints',JointState,queue_size = 10)

fromEncToRadFor1066428 = 4096/(2*math.pi)
fromRncToRadFor12 = (1024*180)/(300*math.pi)
minEncPoseForGripper = 390
fromEncToLinGripper = 7.75
zeroPose = [2048, 2048, 2048, 2048, 512, 680]
countOfJoint = 5
currentState = JointState()
currentState.position = [0,0,0,0,0]

def UpdateCurJointState(curJS):
    global currentState
    if (len(currentState.position)>4):
        currentState.position = curJS.position

def reachingOfThePoint(currentStateList,goalStatelList,error):
    reachingPoint = False
    if(math.fabs(currentStateList[0]-goalStatelList[0])<error and
       math.fabs(currentStateList[1]-goalStatelList[1])<error and
       math.fabs(currentStateList[2]-goalStatelList[2])<error and
       math.fabs(currentStateList[3]-goalStatelList[3])<error and
       math.fabs(currentStateList[4]-goalStatelList[4])<error):
       reachingPoint = True
    return reachingPoint

def parse_msg(msg):
    jointState = JointState()
    msgList = msg.jointState.split()
    jointState.name = msgList[0:countOfJoint]
    jointState.position = msgList[countOfJoint:]
    jointState.position = [float(el) for el in jointState.position] 
    return jointState

def publish_srv_callback(msg):
    msg = parse_msg(msg)
    rate = rospy.Rate(3)
    cmdJoint = JointState()
    cmdJoint.name = msg.name
    while(not reachingOfThePoint(currentState.position,msg.position,0.05)):
        cmdJoint.position = msg.position
        convert_state_and_publish(cmdJoint)
        rate.sleep()
    return publish_cmdResponse(True)


def convert_state_and_publish(msg):
    jointcmd = JointState()
    jointcmd = msg
    poseList = []
    for i in range(len(msg.name)):
        if(msg.name[i] == 'ang_joint_5'):
            reqState = round((msg.position[i]*fromRncToRadFor12)+zeroPose[i])
        elif(msg.name[i] == 'gripper'):
            reqState = round(msg.position[i]*fromEncToLinGripper + minEncPoseForGripper)
        else:
            reqState = round((msg.position[i]*fromEncToRadFor1066428)+zeroPose[i])
        poseList.append(reqState)
    jointcmd.position = poseList
    jointcmd.header.stamp = rospy.Time.now()
    jointPub.publish(jointcmd)

if __name__=='__main__':
    rospy.init_node('convert_and_publish_state')
    rospy.loginfo('Start_convert_and_publish_state_node')
    rospy.Service('/cmd_joint_state_in_manip_coord', publish_cmd, publish_srv_callback)
    rospy.Subscriber('/angle_robot/joint_states',JointState,UpdateCurJointState)
    rospy.spin()
